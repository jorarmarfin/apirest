-- MySQL dump 10.17  Distrib 10.3.12-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: apirest
-- ------------------------------------------------------
-- Server version	10.3.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data_rows`
--

DROP TABLE IF EXISTS `data_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_type_id` int(10) unsigned NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `browse` tinyint(1) NOT NULL DEFAULT 1,
  `read` tinyint(1) NOT NULL DEFAULT 1,
  `edit` tinyint(1) NOT NULL DEFAULT 1,
  `add` tinyint(1) NOT NULL DEFAULT 1,
  `delete` tinyint(1) NOT NULL DEFAULT 1,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `data_rows_data_type_id_foreign` (`data_type_id`),
  CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_rows`
--

LOCK TABLES `data_rows` WRITE;
/*!40000 ALTER TABLE `data_rows` DISABLE KEYS */;
INSERT INTO `data_rows` VALUES (1,1,'id','number','ID',1,0,0,0,0,0,NULL,1),(2,1,'name','text','Name',1,1,1,1,1,1,NULL,2),(3,1,'email','text','Email',1,1,1,1,1,1,NULL,3),(4,1,'password','password','Password',1,0,0,1,1,0,NULL,4),(5,1,'remember_token','text','Remember Token',0,0,0,0,0,0,NULL,5),(6,1,'created_at','timestamp','Created At',0,1,1,0,0,0,NULL,6),(7,1,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,7),(8,1,'avatar','image','Avatar',0,1,1,1,1,1,NULL,8),(9,1,'user_belongsto_role_relationship','relationship','Role',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":0}',10),(10,1,'user_belongstomany_role_relationship','relationship','Roles',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}',11),(11,1,'settings','hidden','Settings',0,0,0,0,0,0,NULL,12),(12,2,'id','number','ID',1,0,0,0,0,0,NULL,1),(13,2,'name','text','Name',1,1,1,1,1,1,NULL,2),(14,2,'created_at','timestamp','Created At',0,0,0,0,0,0,NULL,3),(15,2,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,4),(16,3,'id','number','ID',1,0,0,0,0,0,NULL,1),(17,3,'name','text','Name',1,1,1,1,1,1,NULL,2),(18,3,'created_at','timestamp','Created At',0,0,0,0,0,0,NULL,3),(19,3,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,4),(20,3,'display_name','text','Display Name',1,1,1,1,1,1,NULL,5),(21,1,'role_id','text','Role',1,1,1,1,1,1,NULL,9),(22,4,'id','hidden','Id',1,0,0,0,0,0,'{}',1),(23,4,'codigo','text','Codigo',0,1,1,1,1,1,'{}',2),(24,4,'nombre','text','Nombre',0,1,1,1,1,1,'{}',3),(25,5,'id','hidden','Id',1,0,0,0,0,0,'{}',1),(26,5,'codigo','text','Codigo',0,1,1,1,1,1,'{}',2),(27,5,'nombre','text','Nombre',0,1,1,1,1,1,'{}',3),(28,5,'idregion','text','Idregion',0,1,1,1,1,1,'{}',4),(29,6,'id','hidden','Id',1,0,0,0,0,0,'{}',1),(30,6,'codigo','text','Codigo',0,1,1,1,1,1,'{}',2),(31,6,'nombre','text','Nombre',0,1,1,1,1,1,'{}',3),(32,6,'idprovincia','text','Idprovincia',0,1,1,1,1,1,'{}',4),(33,5,'provincia_belongsto_region_relationship','relationship','region',0,1,1,1,1,1,'{\"model\":\"App\\\\Region\",\"table\":\"region\",\"type\":\"belongsTo\",\"column\":\"idregion\",\"key\":\"id\",\"label\":\"nombre\",\"pivot_table\":\"data_rows\",\"pivot\":\"0\",\"taggable\":\"0\"}',5),(34,6,'distrito_belongsto_provincia_relationship','relationship','provincias',0,1,1,1,1,1,'{\"model\":\"App\\\\Provincia\",\"table\":\"provincias\",\"type\":\"belongsTo\",\"column\":\"idprovincia\",\"key\":\"id\",\"label\":\"nombre\",\"pivot_table\":\"data_rows\",\"pivot\":\"0\",\"taggable\":\"0\"}',5);
/*!40000 ALTER TABLE `data_rows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_types`
--

DROP TABLE IF EXISTS `data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT 0,
  `server_side` tinyint(4) NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `data_types_name_unique` (`name`),
  UNIQUE KEY `data_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_types`
--

LOCK TABLES `data_types` WRITE;
/*!40000 ALTER TABLE `data_types` DISABLE KEYS */;
INSERT INTO `data_types` VALUES (1,'users','users','User','Users','voyager-person','TCG\\Voyager\\Models\\User','TCG\\Voyager\\Policies\\UserPolicy','TCG\\Voyager\\Http\\Controllers\\VoyagerUserController','',1,0,NULL,'2019-04-23 21:06:50','2019-04-23 21:06:50'),(2,'menus','menus','Menu','Menus','voyager-list','TCG\\Voyager\\Models\\Menu',NULL,'','',1,0,NULL,'2019-04-23 21:06:50','2019-04-23 21:06:50'),(3,'roles','roles','Role','Roles','voyager-lock','TCG\\Voyager\\Models\\Role',NULL,'','',1,0,NULL,'2019-04-23 21:06:50','2019-04-23 21:06:50'),(4,'region','region','Region','Regions',NULL,'App\\Region',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}','2019-04-23 21:17:23','2019-04-23 21:17:23'),(5,'provincias','provincias','Provincia','Provincias',NULL,'App\\Provincia',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}','2019-04-23 21:20:57','2019-04-23 21:24:46'),(6,'distrito','distrito','Distrito','Distritos',NULL,'App\\Distrito',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}','2019-04-23 21:22:27','2019-04-23 21:25:18');
/*!40000 ALTER TABLE `data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distrito`
--

DROP TABLE IF EXISTS `distrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distrito` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1868 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distrito`
--

LOCK TABLES `distrito` WRITE;
/*!40000 ALTER TABLE `distrito` DISABLE KEYS */;
INSERT INTO `distrito` VALUES (1,'010101','Chachapoyas',1),(2,'010102','Asunción',1),(3,'010103','Balsas',1),(4,'010104','Cheto',1),(5,'010105','Chiliquin',1),(6,'010106','Chuquibamba',1),(7,'010107','Granada',1),(8,'010108','Huancas',1),(9,'010109','La Jalca',1),(10,'010110','Leimebamba',1),(11,'010111','Levanto',1),(12,'010112','Magdalena',1),(13,'010113','Mariscal Castilla',1),(14,'010114','Molinopampa',1),(15,'010115','Montevideo',1),(16,'010116','Olleros',1),(17,'010117','Quinjalca',1),(18,'010118','San Francisco de Daguas',1),(19,'010119','San Isidro de Maino',1),(20,'010120','Soloco',1),(21,'010121','Sonche',1),(22,'010201','Bagua',2),(23,'010202','Aramango',2),(24,'010203','Copallin',2),(25,'010204','El Parco',2),(26,'010205','Imaza',2),(27,'010206','La Peca',2),(28,'010301','Jumbilla',3),(29,'010302','Chisquilla',3),(30,'010303','Churuja',3),(31,'010304','Corosha',3),(32,'010305','Cuispes',3),(33,'010306','Florida',3),(34,'010307','Jazan',3),(35,'010308','Recta',3),(36,'010309','San Carlos',3),(37,'010310','Shipasbamba',3),(38,'010311','Valera',3),(39,'010312','Yambrasbamba',3),(40,'010401','Nieva',4),(41,'010402','El Cenepa',4),(42,'010403','Río Santiago',4),(43,'010501','Lamud',5),(44,'010502','Camporredondo',5),(45,'010503','Cocabamba',5),(46,'010504','Colcamar',5),(47,'010505','Conila',5),(48,'010506','Inguilpata',5),(49,'010507','Longuita',5),(50,'010508','Lonya Chico',5),(51,'010509','Luya',5),(52,'010510','Luya Viejo',5),(53,'010511','María',5),(54,'010512','Ocalli',5),(55,'010513','Ocumal',5),(56,'010514','Pisuquia',5),(57,'010515','Providencia',5),(58,'010516','San Cristóbal',5),(59,'010517','San Francisco de Yeso',5),(60,'010518','San Jerónimo',5),(61,'010519','San Juan de Lopecancha',5),(62,'010520','Santa Catalina',5),(63,'010521','Santo Tomas',5),(64,'010522','Tingo',5),(65,'010523','Trita',5),(66,'010601','San Nicolás',6),(67,'010602','Chirimoto',6),(68,'010603','Cochamal',6),(69,'010604','Huambo',6),(70,'010605','Limabamba',6),(71,'010606','Longar',6),(72,'010607','Mariscal Benavides',6),(73,'010608','Milpuc',6),(74,'010609','Omia',6),(75,'010610','Santa Rosa',6),(76,'010611','Totora',6),(77,'010612','Vista Alegre',6),(78,'010701','Bagua Grande',7),(79,'010702','Cajaruro',7),(80,'010703','Cumba',7),(81,'010704','El Milagro',7),(82,'010705','Jamalca',7),(83,'010706','Lonya Grande',7),(84,'010707','Yamon',7),(85,'020101','Huaraz',8),(86,'020102','Cochabamba',8),(87,'020103','Colcabamba',8),(88,'020104','Huanchay',8),(89,'020105','Independencia',8),(90,'020106','Jangas',8),(91,'020107','La Libertad',8),(92,'020108','Olleros',8),(93,'020109','Pampas Grande',8),(94,'020110','Pariacoto',8),(95,'020111','Pira',8),(96,'020112','Tarica',8),(97,'020201','Aija',9),(98,'020202','Coris',9),(99,'020203','Huacllan',9),(100,'020204','La Merced',9),(101,'020205','Succha',9),(102,'020301','Llamellin',10),(103,'020302','Aczo',10),(104,'020303','Chaccho',10),(105,'020304','Chingas',10),(106,'020305','Mirgas',10),(107,'020306','San Juan de Rontoy',10),(108,'020401','Chacas',11),(109,'020402','Acochaca',11),(110,'020501','Chiquian',12),(111,'020502','Abelardo Pardo Lezameta',12),(112,'020503','Antonio Raymondi',12),(113,'020504','Aquia',12),(114,'020505','Cajacay',12),(115,'020506','Canis',12),(116,'020507','Colquioc',12),(117,'020508','Huallanca',12),(118,'020509','Huasta',12),(119,'020510','Huayllacayan',12),(120,'020511','La Primavera',12),(121,'020512','Mangas',12),(122,'020513','Pacllon',12),(123,'020514','San Miguel de Corpanqui',12),(124,'020515','Ticllos',12),(125,'020601','Carhuaz',13),(126,'020602','Acopampa',13),(127,'020603','Amashca',13),(128,'020604','Anta',13),(129,'020605','Ataquero',13),(130,'020606','Marcara',13),(131,'020607','Pariahuanca',13),(132,'020608','San Miguel de Aco',13),(133,'020609','Shilla',13),(134,'020610','Tinco',13),(135,'020611','Yungar',13),(136,'020701','San Luis',14),(137,'020702','San Nicolás',14),(138,'020703','Yauya',14),(139,'020801','Casma',15),(140,'020802','Buena Vista Alta',15),(141,'020803','Comandante Noel',15),(142,'020804','Yautan',15),(143,'020901','Corongo',16),(144,'020902','Aco',16),(145,'020903','Bambas',16),(146,'020904','Cusca',16),(147,'020905','La Pampa',16),(148,'020906','Yanac',16),(149,'020907','Yupan',16),(150,'021001','Huari',17),(151,'021002','Anra',17),(152,'021003','Cajay',17),(153,'021004','Chavin de Huantar',17),(154,'021005','Huacachi',17),(155,'021006','Huacchis',17),(156,'021007','Huachis',17),(157,'021008','Huantar',17),(158,'021009','Masin',17),(159,'021010','Paucas',17),(160,'021011','Ponto',17),(161,'021012','Rahuapampa',17),(162,'021013','Rapayan',17),(163,'021014','San Marcos',17),(164,'021015','San Pedro de Chana',17),(165,'021016','Uco',17),(166,'021101','Huarmey',18),(167,'021102','Cochapeti',18),(168,'021103','Culebras',18),(169,'021104','Huayan',18),(170,'021105','Malvas',18),(171,'021201','Caraz',19),(172,'021202','Huallanca',19),(173,'021203','Huata',19),(174,'021204','Huaylas',19),(175,'021205','Mato',19),(176,'021206','Pamparomas',19),(177,'021207','Pueblo Libre',19),(178,'021208','Santa Cruz',19),(179,'021209','Santo Toribio',19),(180,'021210','Yuracmarca',19),(181,'021301','Piscobamba',20),(182,'021302','Casca',20),(183,'021303','Eleazar Guzmán Barron',20),(184,'021304','Fidel Olivas Escudero',20),(185,'021305','Llama',20),(186,'021306','Llumpa',20),(187,'021307','Lucma',20),(188,'021308','Musga',20),(189,'021401','Ocros',21),(190,'021402','Acas',21),(191,'021403','Cajamarquilla',21),(192,'021404','Carhuapampa',21),(193,'021405','Cochas',21),(194,'021406','Congas',21),(195,'021407','Llipa',21),(196,'021408','San Cristóbal de Rajan',21),(197,'021409','San Pedro',21),(198,'021410','Santiago de Chilcas',21),(199,'021501','Cabana',22),(200,'021502','Bolognesi',22),(201,'021503','Conchucos',22),(202,'021504','Huacaschuque',22),(203,'021505','Huandoval',22),(204,'021506','Lacabamba',22),(205,'021507','Llapo',22),(206,'021508','Pallasca',22),(207,'021509','Pampas',22),(208,'021510','Santa Rosa',22),(209,'021511','Tauca',22),(210,'021601','Pomabamba',23),(211,'021602','Huayllan',23),(212,'021603','Parobamba',23),(213,'021604','Quinuabamba',23),(214,'021701','Recuay',24),(215,'021702','Catac',24),(216,'021703','Cotaparaco',24),(217,'021704','Huayllapampa',24),(218,'021705','Llacllin',24),(219,'021706','Marca',24),(220,'021707','Pampas Chico',24),(221,'021708','Pararin',24),(222,'021709','Tapacocha',24),(223,'021710','Ticapampa',24),(224,'021801','Chimbote',25),(225,'021802','Cáceres del Perú',25),(226,'021803','Coishco',25),(227,'021804','Macate',25),(228,'021805','Moro',25),(229,'021806','Nepeña',25),(230,'021807','Samanco',25),(231,'021808','Santa',25),(232,'021809','Nuevo Chimbote',25),(233,'021901','Sihuas',26),(234,'021902','Acobamba',26),(235,'021903','Alfonso Ugarte',26),(236,'021904','Cashapampa',26),(237,'021905','Chingalpo',26),(238,'021906','Huayllabamba',26),(239,'021907','Quiches',26),(240,'021908','Ragash',26),(241,'021909','San Juan',26),(242,'021910','Sicsibamba',26),(243,'022001','Yungay',27),(244,'022002','Cascapara',27),(245,'022003','Mancos',27),(246,'022004','Matacoto',27),(247,'022005','Quillo',27),(248,'022006','Ranrahirca',27),(249,'022007','Shupluy',27),(250,'022008','Yanama',27),(251,'030101','Abancay',28),(252,'030102','Chacoche',28),(253,'030103','Circa',28),(254,'030104','Curahuasi',28),(255,'030105','Huanipaca',28),(256,'030106','Lambrama',28),(257,'030107','Pichirhua',28),(258,'030108','San Pedro de Cachora',28),(259,'030109','Tamburco',28),(260,'030201','Andahuaylas',29),(261,'030202','Andarapa',29),(262,'030203','Chiara',29),(263,'030204','Huancarama',29),(264,'030205','Huancaray',29),(265,'030206','Huayana',29),(266,'030207','Kishuara',29),(267,'030208','Pacobamba',29),(268,'030209','Pacucha',29),(269,'030210','Pampachiri',29),(270,'030211','Pomacocha',29),(271,'030212','San Antonio de Cachi',29),(272,'030213','San Jerónimo',29),(273,'030214','San Miguel de Chaccrampa',29),(274,'030215','Santa María de Chicmo',29),(275,'030216','Talavera',29),(276,'030217','Tumay Huaraca',29),(277,'030218','Turpo',29),(278,'030219','Kaquiabamba',29),(279,'030220','José María Arguedas',29),(280,'030301','Antabamba',30),(281,'030302','El Oro',30),(282,'030303','Huaquirca',30),(283,'030304','Juan Espinoza Medrano',30),(284,'030305','Oropesa',30),(285,'030306','Pachaconas',30),(286,'030307','Sabaino',30),(287,'030401','Chalhuanca',31),(288,'030402','Capaya',31),(289,'030403','Caraybamba',31),(290,'030404','Chapimarca',31),(291,'030405','Colcabamba',31),(292,'030406','Cotaruse',31),(293,'030407','Ihuayllo',31),(294,'030408','Justo Apu Sahuaraura',31),(295,'030409','Lucre',31),(296,'030410','Pocohuanca',31),(297,'030411','San Juan de Chacña',31),(298,'030412','Sañayca',31),(299,'030413','Soraya',31),(300,'030414','Tapairihua',31),(301,'030415','Tintay',31),(302,'030416','Toraya',31),(303,'030417','Yanaca',31),(304,'030501','Tambobamba',32),(305,'030502','Cotabambas',32),(306,'030503','Coyllurqui',32),(307,'030504','Haquira',32),(308,'030505','Mara',32),(309,'030506','Challhuahuacho',32),(310,'030601','Chincheros',33),(311,'030602','Anco_Huallo',33),(312,'030603','Cocharcas',33),(313,'030604','Huaccana',33),(314,'030605','Ocobamba',33),(315,'030606','Ongoy',33),(316,'030607','Uranmarca',33),(317,'030608','Ranracancha',33),(318,'030609','Rocchacc',33),(319,'030610','El Porvenir',33),(320,'030701','Chuquibambilla',34),(321,'030702','Curpahuasi',34),(322,'030703','Gamarra',34),(323,'030704','Huayllati',34),(324,'030705','Mamara',34),(325,'030706','Micaela Bastidas',34),(326,'030707','Pataypampa',34),(327,'030708','Progreso',34),(328,'030709','San Antonio',34),(329,'030710','Santa Rosa',34),(330,'030711','Turpay',34),(331,'030712','Vilcabamba',34),(332,'030713','Virundo',34),(333,'030714','Curasco',34),(334,'040101','Arequipa',35),(335,'040102','Alto Selva Alegre',35),(336,'040103','Cayma',35),(337,'040104','Cerro Colorado',35),(338,'040105','Characato',35),(339,'040106','Chiguata',35),(340,'040107','Jacobo Hunter',35),(341,'040108','La Joya',35),(342,'040109','Mariano Melgar',35),(343,'040110','Miraflores',35),(344,'040111','Mollebaya',35),(345,'040112','Paucarpata',35),(346,'040113','Pocsi',35),(347,'040114','Polobaya',35),(348,'040115','Quequeña',35),(349,'040116','Sabandia',35),(350,'040117','Sachaca',35),(351,'040118','San Juan de Siguas',35),(352,'040119','San Juan de Tarucani',35),(353,'040120','Santa Isabel de Siguas',35),(354,'040121','Santa Rita de Siguas',35),(355,'040122','Socabaya',35),(356,'040123','Tiabaya',35),(357,'040124','Uchumayo',35),(358,'040125','Vitor',35),(359,'040126','Yanahuara',35),(360,'040127','Yarabamba',35),(361,'040128','Yura',35),(362,'040129','José Luis Bustamante Y Rivero',35),(363,'040201','Camaná',36),(364,'040202','José María Quimper',36),(365,'040203','Mariano Nicolás Valcárcel',36),(366,'040204','Mariscal Cáceres',36),(367,'040205','Nicolás de Pierola',36),(368,'040206','Ocoña',36),(369,'040207','Quilca',36),(370,'040208','Samuel Pastor',36),(371,'040301','Caravelí',37),(372,'040302','Acarí',37),(373,'040303','Atico',37),(374,'040304','Atiquipa',37),(375,'040305','Bella Unión',37),(376,'040306','Cahuacho',37),(377,'040307','Chala',37),(378,'040308','Chaparra',37),(379,'040309','Huanuhuanu',37),(380,'040310','Jaqui',37),(381,'040311','Lomas',37),(382,'040312','Quicacha',37),(383,'040313','Yauca',37),(384,'040401','Aplao',38),(385,'040402','Andagua',38),(386,'040403','Ayo',38),(387,'040404','Chachas',38),(388,'040405','Chilcaymarca',38),(389,'040406','Choco',38),(390,'040407','Huancarqui',38),(391,'040408','Machaguay',38),(392,'040409','Orcopampa',38),(393,'040410','Pampacolca',38),(394,'040411','Tipan',38),(395,'040412','Uñon',38),(396,'040413','Uraca',38),(397,'040414','Viraco',38),(398,'040501','Chivay',39),(399,'040502','Achoma',39),(400,'040503','Cabanaconde',39),(401,'040504','Callalli',39),(402,'040505','Caylloma',39),(403,'040506','Coporaque',39),(404,'040507','Huambo',39),(405,'040508','Huanca',39),(406,'040509','Ichupampa',39),(407,'040510','Lari',39),(408,'040511','Lluta',39),(409,'040512','Maca',39),(410,'040513','Madrigal',39),(411,'040514','San Antonio de Chuca',39),(412,'040515','Sibayo',39),(413,'040516','Tapay',39),(414,'040517','Tisco',39),(415,'040518','Tuti',39),(416,'040519','Yanque',39),(417,'040520','Majes',39),(418,'040601','Chuquibamba',40),(419,'040602','Andaray',40),(420,'040603','Cayarani',40),(421,'040604','Chichas',40),(422,'040605','Iray',40),(423,'040606','Río Grande',40),(424,'040607','Salamanca',40),(425,'040608','Yanaquihua',40),(426,'040701','Mollendo',41),(427,'040702','Cocachacra',41),(428,'040703','Dean Valdivia',41),(429,'040704','Islay',41),(430,'040705','Mejia',41),(431,'040706','Punta de Bombón',41),(432,'040801','Cotahuasi',42),(433,'040802','Alca',42),(434,'040803','Charcana',42),(435,'040804','Huaynacotas',42),(436,'040805','Pampamarca',42),(437,'040806','Puyca',42),(438,'040807','Quechualla',42),(439,'040808','Sayla',42),(440,'040809','Tauria',42),(441,'040810','Tomepampa',42),(442,'040811','Toro',42),(443,'050101','Ayacucho',43),(444,'050102','Acocro',43),(445,'050103','Acos Vinchos',43),(446,'050104','Carmen Alto',43),(447,'050105','Chiara',43),(448,'050106','Ocros',43),(449,'050107','Pacaycasa',43),(450,'050108','Quinua',43),(451,'050109','San José de Ticllas',43),(452,'050110','San Juan Bautista',43),(453,'050111','Santiago de Pischa',43),(454,'050112','Socos',43),(455,'050113','Tambillo',43),(456,'050114','Vinchos',43),(457,'050115','Jesús Nazareno',43),(458,'050116','Andrés Avelino Cáceres Dorregaray',43),(459,'050201','Cangallo',44),(460,'050202','Chuschi',44),(461,'050203','Los Morochucos',44),(462,'050204','María Parado de Bellido',44),(463,'050205','Paras',44),(464,'050206','Totos',44),(465,'050301','Sancos',45),(466,'050302','Carapo',45),(467,'050303','Sacsamarca',45),(468,'050304','Santiago de Lucanamarca',45),(469,'050401','Huanta',46),(470,'050402','Ayahuanco',46),(471,'050403','Huamanguilla',46),(472,'050404','Iguain',46),(473,'050405','Luricocha',46),(474,'050406','Santillana',46),(475,'050407','Sivia',46),(476,'050408','Llochegua',46),(477,'050409','Canayre',46),(478,'050410','Uchuraccay',46),(479,'050411','Pucacolpa',46),(480,'050412','Chaca',46),(481,'050501','San Miguel',47),(482,'050502','Anco',47),(483,'050503','Ayna',47),(484,'050504','Chilcas',47),(485,'050505','Chungui',47),(486,'050506','Luis Carranza',47),(487,'050507','Santa Rosa',47),(488,'050508','Tambo',47),(489,'050509','Samugari',47),(490,'050510','Anchihuay',47),(491,'050601','Puquio',48),(492,'050602','Aucara',48),(493,'050603','Cabana',48),(494,'050604','Carmen Salcedo',48),(495,'050605','Chaviña',48),(496,'050606','Chipao',48),(497,'050607','Huac-Huas',48),(498,'050608','Laramate',48),(499,'050609','Leoncio Prado',48),(500,'050610','Llauta',48),(501,'050611','Lucanas',48),(502,'050612','Ocaña',48),(503,'050613','Otoca',48),(504,'050614','Saisa',48),(505,'050615','San Cristóbal',48),(506,'050616','San Juan',48),(507,'050617','San Pedro',48),(508,'050618','San Pedro de Palco',48),(509,'050619','Sancos',48),(510,'050620','Santa Ana de Huaycahuacho',48),(511,'050621','Santa Lucia',48),(512,'050701','Coracora',49),(513,'050702','Chumpi',49),(514,'050703','Coronel Castañeda',49),(515,'050704','Pacapausa',49),(516,'050705','Pullo',49),(517,'050706','Puyusca',49),(518,'050707','San Francisco de Ravacayco',49),(519,'050708','Upahuacho',49),(520,'050801','Pausa',50),(521,'050802','Colta',50),(522,'050803','Corculla',50),(523,'050804','Lampa',50),(524,'050805','Marcabamba',50),(525,'050806','Oyolo',50),(526,'050807','Pararca',50),(527,'050808','San Javier de Alpabamba',50),(528,'050809','San José de Ushua',50),(529,'050810','Sara Sara',50),(530,'050901','Querobamba',51),(531,'050902','Belén',51),(532,'050903','Chalcos',51),(533,'050904','Chilcayoc',51),(534,'050905','Huacaña',51),(535,'050906','Morcolla',51),(536,'050907','Paico',51),(537,'050908','San Pedro de Larcay',51),(538,'050909','San Salvador de Quije',51),(539,'050910','Santiago de Paucaray',51),(540,'050911','Soras',51),(541,'051001','Huancapi',52),(542,'051002','Alcamenca',52),(543,'051003','Apongo',52),(544,'051004','Asquipata',52),(545,'051005','Canaria',52),(546,'051006','Cayara',52),(547,'051007','Colca',52),(548,'051008','Huamanquiquia',52),(549,'051009','Huancaraylla',52),(550,'051010','Huaya',52),(551,'051011','Sarhua',52),(552,'051012','Vilcanchos',52),(553,'051101','Vilcas Huaman',53),(554,'051102','Accomarca',53),(555,'051103','Carhuanca',53),(556,'051104','Concepción',53),(557,'051105','Huambalpa',53),(558,'051106','Independencia',53),(559,'051107','Saurama',53),(560,'051108','Vischongo',53),(561,'060101','Cajamarca',54),(562,'060102','Asunción',54),(563,'060103','Chetilla',54),(564,'060104','Cospan',54),(565,'060105','Encañada',54),(566,'060106','Jesús',54),(567,'060107','Llacanora',54),(568,'060108','Los Baños del Inca',54),(569,'060109','Magdalena',54),(570,'060110','Matara',54),(571,'060111','Namora',54),(572,'060112','San Juan',54),(573,'060201','Cajabamba',55),(574,'060202','Cachachi',55),(575,'060203','Condebamba',55),(576,'060204','Sitacocha',55),(577,'060301','Celendín',56),(578,'060302','Chumuch',56),(579,'060303','Cortegana',56),(580,'060304','Huasmin',56),(581,'060305','Jorge Chávez',56),(582,'060306','José Gálvez',56),(583,'060307','Miguel Iglesias',56),(584,'060308','Oxamarca',56),(585,'060309','Sorochuco',56),(586,'060310','Sucre',56),(587,'060311','Utco',56),(588,'060312','La Libertad de Pallan',56),(589,'060401','Chota',57),(590,'060402','Anguia',57),(591,'060403','Chadin',57),(592,'060404','Chiguirip',57),(593,'060405','Chimban',57),(594,'060406','Choropampa',57),(595,'060407','Cochabamba',57),(596,'060408','Conchan',57),(597,'060409','Huambos',57),(598,'060410','Lajas',57),(599,'060411','Llama',57),(600,'060412','Miracosta',57),(601,'060413','Paccha',57),(602,'060414','Pion',57),(603,'060415','Querocoto',57),(604,'060416','San Juan de Licupis',57),(605,'060417','Tacabamba',57),(606,'060418','Tocmoche',57),(607,'060419','Chalamarca',57),(608,'060501','Contumaza',58),(609,'060502','Chilete',58),(610,'060503','Cupisnique',58),(611,'060504','Guzmango',58),(612,'060505','San Benito',58),(613,'060506','Santa Cruz de Toledo',58),(614,'060507','Tantarica',58),(615,'060508','Yonan',58),(616,'060601','Cutervo',59),(617,'060602','Callayuc',59),(618,'060603','Choros',59),(619,'060604','Cujillo',59),(620,'060605','La Ramada',59),(621,'060606','Pimpingos',59),(622,'060607','Querocotillo',59),(623,'060608','San Andrés de Cutervo',59),(624,'060609','San Juan de Cutervo',59),(625,'060610','San Luis de Lucma',59),(626,'060611','Santa Cruz',59),(627,'060612','Santo Domingo de la Capilla',59),(628,'060613','Santo Tomas',59),(629,'060614','Socota',59),(630,'060615','Toribio Casanova',59),(631,'060701','Bambamarca',60),(632,'060702','Chugur',60),(633,'060703','Hualgayoc',60),(634,'060801','Jaén',61),(635,'060802','Bellavista',61),(636,'060803','Chontali',61),(637,'060804','Colasay',61),(638,'060805','Huabal',61),(639,'060806','Las Pirias',61),(640,'060807','Pomahuaca',61),(641,'060808','Pucara',61),(642,'060809','Sallique',61),(643,'060810','San Felipe',61),(644,'060811','San José del Alto',61),(645,'060812','Santa Rosa',61),(646,'060901','San Ignacio',62),(647,'060902','Chirinos',62),(648,'060903','Huarango',62),(649,'060904','La Coipa',62),(650,'060905','Namballe',62),(651,'060906','San José de Lourdes',62),(652,'060907','Tabaconas',62),(653,'061001','Pedro Gálvez',63),(654,'061002','Chancay',63),(655,'061003','Eduardo Villanueva',63),(656,'061004','Gregorio Pita',63),(657,'061005','Ichocan',63),(658,'061006','José Manuel Quiroz',63),(659,'061007','José Sabogal',63),(660,'061101','San Miguel',64),(661,'061102','Bolívar',64),(662,'061103','Calquis',64),(663,'061104','Catilluc',64),(664,'061105','El Prado',64),(665,'061106','La Florida',64),(666,'061107','Llapa',64),(667,'061108','Nanchoc',64),(668,'061109','Niepos',64),(669,'061110','San Gregorio',64),(670,'061111','San Silvestre de Cochan',64),(671,'061112','Tongod',64),(672,'061113','Unión Agua Blanca',64),(673,'061201','San Pablo',65),(674,'061202','San Bernardino',65),(675,'061203','San Luis',65),(676,'061204','Tumbaden',65),(677,'061301','Santa Cruz',66),(678,'061302','Andabamba',66),(679,'061303','Catache',66),(680,'061304','Chancaybaños',66),(681,'061305','La Esperanza',66),(682,'061306','Ninabamba',66),(683,'061307','Pulan',66),(684,'061308','Saucepampa',66),(685,'061309','Sexi',66),(686,'061310','Uticyacu',66),(687,'061311','Yauyucan',66),(688,'070101','Callao',67),(689,'070102','Bellavista',67),(690,'070103','Carmen de la Legua Reynoso',67),(691,'070104','La Perla',67),(692,'070105','La Punta',67),(693,'070106','Ventanilla',67),(694,'070107','Mi Perú',67),(695,'080101','Cusco',68),(696,'080102','Ccorca',68),(697,'080103','Poroy',68),(698,'080104','San Jerónimo',68),(699,'080105','San Sebastian',68),(700,'080106','Santiago',68),(701,'080107','Saylla',68),(702,'080108','Wanchaq',68),(703,'080201','Acomayo',69),(704,'080202','Acopia',69),(705,'080203','Acos',69),(706,'080204','Mosoc Llacta',69),(707,'080205','Pomacanchi',69),(708,'080206','Rondocan',69),(709,'080207','Sangarara',69),(710,'080301','Anta',70),(711,'080302','Ancahuasi',70),(712,'080303','Cachimayo',70),(713,'080304','Chinchaypujio',70),(714,'080305','Huarocondo',70),(715,'080306','Limatambo',70),(716,'080307','Mollepata',70),(717,'080308','Pucyura',70),(718,'080309','Zurite',70),(719,'080401','Calca',71),(720,'080402','Coya',71),(721,'080403','Lamay',71),(722,'080404','Lares',71),(723,'080405','Pisac',71),(724,'080406','San Salvador',71),(725,'080407','Taray',71),(726,'080408','Yanatile',71),(727,'080501','Yanaoca',72),(728,'080502','Checca',72),(729,'080503','Kunturkanki',72),(730,'080504','Langui',72),(731,'080505','Layo',72),(732,'080506','Pampamarca',72),(733,'080507','Quehue',72),(734,'080508','Tupac Amaru',72),(735,'080601','Sicuani',73),(736,'080602','Checacupe',73),(737,'080603','Combapata',73),(738,'080604','Marangani',73),(739,'080605','Pitumarca',73),(740,'080606','San Pablo',73),(741,'080607','San Pedro',73),(742,'080608','Tinta',73),(743,'080701','Santo Tomas',74),(744,'080702','Capacmarca',74),(745,'080703','Chamaca',74),(746,'080704','Colquemarca',74),(747,'080705','Livitaca',74),(748,'080706','Llusco',74),(749,'080707','Quiñota',74),(750,'080708','Velille',74),(751,'080801','Espinar',75),(752,'080802','Condoroma',75),(753,'080803','Coporaque',75),(754,'080804','Ocoruro',75),(755,'080805','Pallpata',75),(756,'080806','Pichigua',75),(757,'080807','Suyckutambo',75),(758,'080808','Alto Pichigua',75),(759,'080901','Santa Ana',76),(760,'080902','Echarate',76),(761,'080903','Huayopata',76),(762,'080904','Maranura',76),(763,'080905','Ocobamba',76),(764,'080906','Quellouno',76),(765,'080907','Kimbiri',76),(766,'080908','Santa Teresa',76),(767,'080909','Vilcabamba',76),(768,'080910','Pichari',76),(769,'080911','Inkawasi',76),(770,'080912','Villa Virgen',76),(771,'080913','Villa Kintiarina',76),(772,'081001','Paruro',77),(773,'081002','Accha',77),(774,'081003','Ccapi',77),(775,'081004','Colcha',77),(776,'081005','Huanoquite',77),(777,'081006','Omacha',77),(778,'081007','Paccaritambo',77),(779,'081008','Pillpinto',77),(780,'081009','Yaurisque',77),(781,'081101','Paucartambo',78),(782,'081102','Caicay',78),(783,'081103','Challabamba',78),(784,'081104','Colquepata',78),(785,'081105','Huancarani',78),(786,'081106','Kosñipata',78),(787,'081201','Urcos',79),(788,'081202','Andahuaylillas',79),(789,'081203','Camanti',79),(790,'081204','Ccarhuayo',79),(791,'081205','Ccatca',79),(792,'081206','Cusipata',79),(793,'081207','Huaro',79),(794,'081208','Lucre',79),(795,'081209','Marcapata',79),(796,'081210','Ocongate',79),(797,'081211','Oropesa',79),(798,'081212','Quiquijana',79),(799,'081301','Urubamba',80),(800,'081302','Chinchero',80),(801,'081303','Huayllabamba',80),(802,'081304','Machupicchu',80),(803,'081305','Maras',80),(804,'081306','Ollantaytambo',80),(805,'081307','Yucay',80),(806,'090101','Huancavelica',81),(807,'090102','Acobambilla',81),(808,'090103','Acoria',81),(809,'090104','Conayca',81),(810,'090105','Cuenca',81),(811,'090106','Huachocolpa',81),(812,'090107','Huayllahuara',81),(813,'090108','Izcuchaca',81),(814,'090109','Laria',81),(815,'090110','Manta',81),(816,'090111','Mariscal Cáceres',81),(817,'090112','Moya',81),(818,'090113','Nuevo Occoro',81),(819,'090114','Palca',81),(820,'090115','Pilchaca',81),(821,'090116','Vilca',81),(822,'090117','Yauli',81),(823,'090118','Ascensión',81),(824,'090119','Huando',81),(825,'090201','Acobamba',82),(826,'090202','Andabamba',82),(827,'090203','Anta',82),(828,'090204','Caja',82),(829,'090205','Marcas',82),(830,'090206','Paucara',82),(831,'090207','Pomacocha',82),(832,'090208','Rosario',82),(833,'090301','Lircay',83),(834,'090302','Anchonga',83),(835,'090303','Callanmarca',83),(836,'090304','Ccochaccasa',83),(837,'090305','Chincho',83),(838,'090306','Congalla',83),(839,'090307','Huanca-Huanca',83),(840,'090308','Huayllay Grande',83),(841,'090309','Julcamarca',83),(842,'090310','San Antonio de Antaparco',83),(843,'090311','Santo Tomas de Pata',83),(844,'090312','Secclla',83),(845,'090401','Castrovirreyna',84),(846,'090402','Arma',84),(847,'090403','Aurahua',84),(848,'090404','Capillas',84),(849,'090405','Chupamarca',84),(850,'090406','Cocas',84),(851,'090407','Huachos',84),(852,'090408','Huamatambo',84),(853,'090409','Mollepampa',84),(854,'090410','San Juan',84),(855,'090411','Santa Ana',84),(856,'090412','Tantara',84),(857,'090413','Ticrapo',84),(858,'090501','Churcampa',85),(859,'090502','Anco',85),(860,'090503','Chinchihuasi',85),(861,'090504','El Carmen',85),(862,'090505','La Merced',85),(863,'090506','Locroja',85),(864,'090507','Paucarbamba',85),(865,'090508','San Miguel de Mayocc',85),(866,'090509','San Pedro de Coris',85),(867,'090510','Pachamarca',85),(868,'090511','Cosme',85),(869,'090601','Huaytara',86),(870,'090602','Ayavi',86),(871,'090603','Córdova',86),(872,'090604','Huayacundo Arma',86),(873,'090605','Laramarca',86),(874,'090606','Ocoyo',86),(875,'090607','Pilpichaca',86),(876,'090608','Querco',86),(877,'090609','Quito-Arma',86),(878,'090610','San Antonio de Cusicancha',86),(879,'090611','San Francisco de Sangayaico',86),(880,'090612','San Isidro',86),(881,'090613','Santiago de Chocorvos',86),(882,'090614','Santiago de Quirahuara',86),(883,'090615','Santo Domingo de Capillas',86),(884,'090616','Tambo',86),(885,'090701','Pampas',87),(886,'090702','Acostambo',87),(887,'090703','Acraquia',87),(888,'090704','Ahuaycha',87),(889,'090705','Colcabamba',87),(890,'090706','Daniel Hernández',87),(891,'090707','Huachocolpa',87),(892,'090709','Huaribamba',87),(893,'090710','Ñahuimpuquio',87),(894,'090711','Pazos',87),(895,'090713','Quishuar',87),(896,'090714','Salcabamba',87),(897,'090715','Salcahuasi',87),(898,'090716','San Marcos de Rocchac',87),(899,'090717','Surcubamba',87),(900,'090718','Tintay Puncu',87),(901,'090719','Quichuas',87),(902,'090720','Andaymarca',87),(903,'090721','Roble',87),(904,'090722','Pichos',87),(905,'100101','Huanuco',88),(906,'100102','Amarilis',88),(907,'100103','Chinchao',88),(908,'100104','Churubamba',88),(909,'100105','Margos',88),(910,'100106','Quisqui (Kichki)',88),(911,'100107','San Francisco de Cayran',88),(912,'100108','San Pedro de Chaulan',88),(913,'100109','Santa María del Valle',88),(914,'100110','Yarumayo',88),(915,'100111','Pillco Marca',88),(916,'100112','Yacus',88),(917,'100113','San Pablo de Pillao',88),(918,'100201','Ambo',89),(919,'100202','Cayna',89),(920,'100203','Colpas',89),(921,'100204','Conchamarca',89),(922,'100205','Huacar',89),(923,'100206','San Francisco',89),(924,'100207','San Rafael',89),(925,'100208','Tomay Kichwa',89),(926,'100301','La Unión',90),(927,'100307','Chuquis',90),(928,'100311','Marías',90),(929,'100313','Pachas',90),(930,'100316','Quivilla',90),(931,'100317','Ripan',90),(932,'100321','Shunqui',90),(933,'100322','Sillapata',90),(934,'100323','Yanas',90),(935,'100401','Huacaybamba',91),(936,'100402','Canchabamba',91),(937,'100403','Cochabamba',91),(938,'100404','Pinra',91),(939,'100501','Llata',92),(940,'100502','Arancay',92),(941,'100503','Chavín de Pariarca',92),(942,'100504','Jacas Grande',92),(943,'100505','Jircan',92),(944,'100506','Miraflores',92),(945,'100507','Monzón',92),(946,'100508','Punchao',92),(947,'100509','Puños',92),(948,'100510','Singa',92),(949,'100511','Tantamayo',92),(950,'100601','Rupa-Rupa',93),(951,'100602','Daniel Alomía Robles',93),(952,'100603','Hermílio Valdizan',93),(953,'100604','José Crespo y Castillo',93),(954,'100605','Luyando',93),(955,'100606','Mariano Damaso Beraun',93),(956,'100607','Pucayacu',93),(957,'100608','Castillo Grande',93),(958,'100701','Huacrachuco',94),(959,'100702','Cholon',94),(960,'100703','San Buenaventura',94),(961,'100704','La Morada',94),(962,'100705','Santa Rosa de Alto Yanajanca',94),(963,'100801','Panao',95),(964,'100802','Chaglla',95),(965,'100803','Molino',95),(966,'100804','Umari',95),(967,'100901','Puerto Inca',96),(968,'100902','Codo del Pozuzo',96),(969,'100903','Honoria',96),(970,'100904','Tournavista',96),(971,'100905','Yuyapichis',96),(972,'101001','Jesús',97),(973,'101002','Baños',97),(974,'101003','Jivia',97),(975,'101004','Queropalca',97),(976,'101005','Rondos',97),(977,'101006','San Francisco de Asís',97),(978,'101007','San Miguel de Cauri',97),(979,'101101','Chavinillo',98),(980,'101102','Cahuac',98),(981,'101103','Chacabamba',98),(982,'101104','Aparicio Pomares',98),(983,'101105','Jacas Chico',98),(984,'101106','Obas',98),(985,'101107','Pampamarca',98),(986,'101108','Choras',98),(987,'110101','Ica',99),(988,'110102','La Tinguiña',99),(989,'110103','Los Aquijes',99),(990,'110104','Ocucaje',99),(991,'110105','Pachacutec',99),(992,'110106','Parcona',99),(993,'110107','Pueblo Nuevo',99),(994,'110108','Salas',99),(995,'110109','San José de Los Molinos',99),(996,'110110','San Juan Bautista',99),(997,'110111','Santiago',99),(998,'110112','Subtanjalla',99),(999,'110113','Tate',99),(1000,'110114','Yauca del Rosario',99),(1001,'110201','Chincha Alta',100),(1002,'110202','Alto Laran',100),(1003,'110203','Chavin',100),(1004,'110204','Chincha Baja',100),(1005,'110205','El Carmen',100),(1006,'110206','Grocio Prado',100),(1007,'110207','Pueblo Nuevo',100),(1008,'110208','San Juan de Yanac',100),(1009,'110209','San Pedro de Huacarpana',100),(1010,'110210','Sunampe',100),(1011,'110211','Tambo de Mora',100),(1012,'110301','Nasca',101),(1013,'110302','Changuillo',101),(1014,'110303','El Ingenio',101),(1015,'110304','Marcona',101),(1016,'110305','Vista Alegre',101),(1017,'110401','Palpa',102),(1018,'110402','Llipata',102),(1019,'110403','Río Grande',102),(1020,'110404','Santa Cruz',102),(1021,'110405','Tibillo',102),(1022,'110501','Pisco',103),(1023,'110502','Huancano',103),(1024,'110503','Humay',103),(1025,'110504','Independencia',103),(1026,'110505','Paracas',103),(1027,'110506','San Andrés',103),(1028,'110507','San Clemente',103),(1029,'110508','Tupac Amaru Inca',103),(1030,'120101','Huancayo',104),(1031,'120104','Carhuacallanga',104),(1032,'120105','Chacapampa',104),(1033,'120106','Chicche',104),(1034,'120107','Chilca',104),(1035,'120108','Chongos Alto',104),(1036,'120111','Chupuro',104),(1037,'120112','Colca',104),(1038,'120113','Cullhuas',104),(1039,'120114','El Tambo',104),(1040,'120116','Huacrapuquio',104),(1041,'120117','Hualhuas',104),(1042,'120119','Huancan',104),(1043,'120120','Huasicancha',104),(1044,'120121','Huayucachi',104),(1045,'120122','Ingenio',104),(1046,'120124','Pariahuanca',104),(1047,'120125','Pilcomayo',104),(1048,'120126','Pucara',104),(1049,'120127','Quichuay',104),(1050,'120128','Quilcas',104),(1051,'120129','San Agustín',104),(1052,'120130','San Jerónimo de Tunan',104),(1053,'120132','Saño',104),(1054,'120133','Sapallanga',104),(1055,'120134','Sicaya',104),(1056,'120135','Santo Domingo de Acobamba',104),(1057,'120136','Viques',104),(1058,'120201','Concepción',105),(1059,'120202','Aco',105),(1060,'120203','Andamarca',105),(1061,'120204','Chambara',105),(1062,'120205','Cochas',105),(1063,'120206','Comas',105),(1064,'120207','Heroínas Toledo',105),(1065,'120208','Manzanares',105),(1066,'120209','Mariscal Castilla',105),(1067,'120210','Matahuasi',105),(1068,'120211','Mito',105),(1069,'120212','Nueve de Julio',105),(1070,'120213','Orcotuna',105),(1071,'120214','San José de Quero',105),(1072,'120215','Santa Rosa de Ocopa',105),(1073,'120301','Chanchamayo',106),(1074,'120302','Perene',106),(1075,'120303','Pichanaqui',106),(1076,'120304','San Luis de Shuaro',106),(1077,'120305','San Ramón',106),(1078,'120306','Vitoc',106),(1079,'120401','Jauja',107),(1080,'120402','Acolla',107),(1081,'120403','Apata',107),(1082,'120404','Ataura',107),(1083,'120405','Canchayllo',107),(1084,'120406','Curicaca',107),(1085,'120407','El Mantaro',107),(1086,'120408','Huamali',107),(1087,'120409','Huaripampa',107),(1088,'120410','Huertas',107),(1089,'120411','Janjaillo',107),(1090,'120412','Julcán',107),(1091,'120413','Leonor Ordóñez',107),(1092,'120414','Llocllapampa',107),(1093,'120415','Marco',107),(1094,'120416','Masma',107),(1095,'120417','Masma Chicche',107),(1096,'120418','Molinos',107),(1097,'120419','Monobamba',107),(1098,'120420','Muqui',107),(1099,'120421','Muquiyauyo',107),(1100,'120422','Paca',107),(1101,'120423','Paccha',107),(1102,'120424','Pancan',107),(1103,'120425','Parco',107),(1104,'120426','Pomacancha',107),(1105,'120427','Ricran',107),(1106,'120428','San Lorenzo',107),(1107,'120429','San Pedro de Chunan',107),(1108,'120430','Sausa',107),(1109,'120431','Sincos',107),(1110,'120432','Tunan Marca',107),(1111,'120433','Yauli',107),(1112,'120434','Yauyos',107),(1113,'120501','Junin',108),(1114,'120502','Carhuamayo',108),(1115,'120503','Ondores',108),(1116,'120504','Ulcumayo',108),(1117,'120601','Satipo',109),(1118,'120602','Coviriali',109),(1119,'120603','Llaylla',109),(1120,'120604','Mazamari',109),(1121,'120605','Pampa Hermosa',109),(1122,'120606','Pangoa',109),(1123,'120607','Río Negro',109),(1124,'120608','Río Tambo',109),(1125,'120609','Vizcatan del Ene',109),(1126,'120701','Tarma',110),(1127,'120702','Acobamba',110),(1128,'120703','Huaricolca',110),(1129,'120704','Huasahuasi',110),(1130,'120705','La Unión',110),(1131,'120706','Palca',110),(1132,'120707','Palcamayo',110),(1133,'120708','San Pedro de Cajas',110),(1134,'120709','Tapo',110),(1135,'120801','La Oroya',111),(1136,'120802','Chacapalpa',111),(1137,'120803','Huay-Huay',111),(1138,'120804','Marcapomacocha',111),(1139,'120805','Morococha',111),(1140,'120806','Paccha',111),(1141,'120807','Santa Bárbara de Carhuacayan',111),(1142,'120808','Santa Rosa de Sacco',111),(1143,'120809','Suitucancha',111),(1144,'120810','Yauli',111),(1145,'120901','Chupaca',112),(1146,'120902','Ahuac',112),(1147,'120903','Chongos Bajo',112),(1148,'120904','Huachac',112),(1149,'120905','Huamancaca Chico',112),(1150,'120906','San Juan de Iscos',112),(1151,'120907','San Juan de Jarpa',112),(1152,'120908','Tres de Diciembre',112),(1153,'120909','Yanacancha',112),(1154,'130101','Trujillo',113),(1155,'130102','El Porvenir',113),(1156,'130103','Florencia de Mora',113),(1157,'130104','Huanchaco',113),(1158,'130105','La Esperanza',113),(1159,'130106','Laredo',113),(1160,'130107','Moche',113),(1161,'130108','Poroto',113),(1162,'130109','Salaverry',113),(1163,'130110','Simbal',113),(1164,'130111','Victor Larco Herrera',113),(1165,'130201','Ascope',114),(1166,'130202','Chicama',114),(1167,'130203','Chocope',114),(1168,'130204','Magdalena de Cao',114),(1169,'130205','Paijan',114),(1170,'130206','Rázuri',114),(1171,'130207','Santiago de Cao',114),(1172,'130208','Casa Grande',114),(1173,'130301','Bolívar',115),(1174,'130302','Bambamarca',115),(1175,'130303','Condormarca',115),(1176,'130304','Longotea',115),(1177,'130305','Uchumarca',115),(1178,'130306','Ucuncha',115),(1179,'130401','Chepen',116),(1180,'130402','Pacanga',116),(1181,'130403','Pueblo Nuevo',116),(1182,'130501','Julcan',117),(1183,'130502','Calamarca',117),(1184,'130503','Carabamba',117),(1185,'130504','Huaso',117),(1186,'130601','Otuzco',118),(1187,'130602','Agallpampa',118),(1188,'130604','Charat',118),(1189,'130605','Huaranchal',118),(1190,'130606','La Cuesta',118),(1191,'130608','Mache',118),(1192,'130610','Paranday',118),(1193,'130611','Salpo',118),(1194,'130613','Sinsicap',118),(1195,'130614','Usquil',118),(1196,'130701','San Pedro de Lloc',119),(1197,'130702','Guadalupe',119),(1198,'130703','Jequetepeque',119),(1199,'130704','Pacasmayo',119),(1200,'130705','San José',119),(1201,'130801','Tayabamba',120),(1202,'130802','Buldibuyo',120),(1203,'130803','Chillia',120),(1204,'130804','Huancaspata',120),(1205,'130805','Huaylillas',120),(1206,'130806','Huayo',120),(1207,'130807','Ongon',120),(1208,'130808','Parcoy',120),(1209,'130809','Pataz',120),(1210,'130810','Pias',120),(1211,'130811','Santiago de Challas',120),(1212,'130812','Taurija',120),(1213,'130813','Urpay',120),(1214,'130901','Huamachuco',121),(1215,'130902','Chugay',121),(1216,'130903','Cochorco',121),(1217,'130904','Curgos',121),(1218,'130905','Marcabal',121),(1219,'130906','Sanagoran',121),(1220,'130907','Sarin',121),(1221,'130908','Sartimbamba',121),(1222,'131001','Santiago de Chuco',122),(1223,'131002','Angasmarca',122),(1224,'131003','Cachicadan',122),(1225,'131004','Mollebamba',122),(1226,'131005','Mollepata',122),(1227,'131006','Quiruvilca',122),(1228,'131007','Santa Cruz de Chuca',122),(1229,'131008','Sitabamba',122),(1230,'131101','Cascas',123),(1231,'131102','Lucma',123),(1232,'131103','Marmot',123),(1233,'131104','Sayapullo',123),(1234,'131201','Viru',124),(1235,'131202','Chao',124),(1236,'131203','Guadalupito',124),(1237,'140101','Chiclayo',125),(1238,'140102','Chongoyape',125),(1239,'140103','Eten',125),(1240,'140104','Eten Puerto',125),(1241,'140105','José Leonardo Ortiz',125),(1242,'140106','La Victoria',125),(1243,'140107','Lagunas',125),(1244,'140108','Monsefu',125),(1245,'140109','Nueva Arica',125),(1246,'140110','Oyotun',125),(1247,'140111','Picsi',125),(1248,'140112','Pimentel',125),(1249,'140113','Reque',125),(1250,'140114','Santa Rosa',125),(1251,'140115','Saña',125),(1252,'140116','Cayalti',125),(1253,'140117','Patapo',125),(1254,'140118','Pomalca',125),(1255,'140119','Pucala',125),(1256,'140120','Tuman',125),(1257,'140201','Ferreñafe',126),(1258,'140202','Cañaris',126),(1259,'140203','Incahuasi',126),(1260,'140204','Manuel Antonio Mesones Muro',126),(1261,'140205','Pitipo',126),(1262,'140206','Pueblo Nuevo',126),(1263,'140301','Lambayeque',127),(1264,'140302','Chochope',127),(1265,'140303','Illimo',127),(1266,'140304','Jayanca',127),(1267,'140305','Mochumi',127),(1268,'140306','Morrope',127),(1269,'140307','Motupe',127),(1270,'140308','Olmos',127),(1271,'140309','Pacora',127),(1272,'140310','Salas',127),(1273,'140311','San José',127),(1274,'140312','Tucume',127),(1275,'150101','Lima',128),(1276,'150102','Ancón',128),(1277,'150103','Ate',128),(1278,'150104','Barranco',128),(1279,'150105','Breña',128),(1280,'150106','Carabayllo',128),(1281,'150107','Chaclacayo',128),(1282,'150108','Chorrillos',128),(1283,'150109','Cieneguilla',128),(1284,'150110','Comas',128),(1285,'150111','El Agustino',128),(1286,'150112','Independencia',128),(1287,'150113','Jesús María',128),(1288,'150114','La Molina',128),(1289,'150115','La Victoria',128),(1290,'150116','Lince',128),(1291,'150117','Los Olivos',128),(1292,'150118','Lurigancho',128),(1293,'150119','Lurin',128),(1294,'150120','Magdalena del Mar',128),(1295,'150121','Pueblo Libre',128),(1296,'150122','Miraflores',128),(1297,'150123','Pachacamac',128),(1298,'150124','Pucusana',128),(1299,'150125','Puente Piedra',128),(1300,'150126','Punta Hermosa',128),(1301,'150127','Punta Negra',128),(1302,'150128','Rímac',128),(1303,'150129','San Bartolo',128),(1304,'150130','San Borja',128),(1305,'150131','San Isidro',128),(1306,'150132','San Juan de Lurigancho',128),(1307,'150133','San Juan de Miraflores',128),(1308,'150134','San Luis',128),(1309,'150135','San Martín de Porres',128),(1310,'150136','San Miguel',128),(1311,'150137','Santa Anita',128),(1312,'150138','Santa María del Mar',128),(1313,'150139','Santa Rosa',128),(1314,'150140','Santiago de Surco',128),(1315,'150141','Surquillo',128),(1316,'150142','Villa El Salvador',128),(1317,'150143','Villa María del Triunfo',128),(1318,'150201','Barranca',129),(1319,'150202','Paramonga',129),(1320,'150203','Pativilca',129),(1321,'150204','Supe',129),(1322,'150205','Supe Puerto',129),(1323,'150301','Cajatambo',130),(1324,'150302','Copa',130),(1325,'150303','Gorgor',130),(1326,'150304','Huancapon',130),(1327,'150305','Manas',130),(1328,'150401','Canta',131),(1329,'150402','Arahuay',131),(1330,'150403','Huamantanga',131),(1331,'150404','Huaros',131),(1332,'150405','Lachaqui',131),(1333,'150406','San Buenaventura',131),(1334,'150407','Santa Rosa de Quives',131),(1335,'150501','San Vicente de Cañete',132),(1336,'150502','Asia',132),(1337,'150503','Calango',132),(1338,'150504','Cerro Azul',132),(1339,'150505','Chilca',132),(1340,'150506','Coayllo',132),(1341,'150507','Imperial',132),(1342,'150508','Lunahuana',132),(1343,'150509','Mala',132),(1344,'150510','Nuevo Imperial',132),(1345,'150511','Pacaran',132),(1346,'150512','Quilmana',132),(1347,'150513','San Antonio',132),(1348,'150514','San Luis',132),(1349,'150515','Santa Cruz de Flores',132),(1350,'150516','Zúñiga',132),(1351,'150601','Huaral',133),(1352,'150602','Atavillos Alto',133),(1353,'150603','Atavillos Bajo',133),(1354,'150604','Aucallama',133),(1355,'150605','Chancay',133),(1356,'150606','Ihuari',133),(1357,'150607','Lampian',133),(1358,'150608','Pacaraos',133),(1359,'150609','San Miguel de Acos',133),(1360,'150610','Santa Cruz de Andamarca',133),(1361,'150611','Sumbilca',133),(1362,'150612','Veintisiete de Noviembre',133),(1363,'150701','Matucana',134),(1364,'150702','Antioquia',134),(1365,'150703','Callahuanca',134),(1366,'150704','Carampoma',134),(1367,'150705','Chicla',134),(1368,'150706','Cuenca',134),(1369,'150707','Huachupampa',134),(1370,'150708','Huanza',134),(1371,'150709','Huarochiri',134),(1372,'150710','Lahuaytambo',134),(1373,'150711','Langa',134),(1374,'150712','Laraos',134),(1375,'150713','Mariatana',134),(1376,'150714','Ricardo Palma',134),(1377,'150715','San Andrés de Tupicocha',134),(1378,'150716','San Antonio',134),(1379,'150717','San Bartolomé',134),(1380,'150718','San Damian',134),(1381,'150719','San Juan de Iris',134),(1382,'150720','San Juan de Tantaranche',134),(1383,'150721','San Lorenzo de Quinti',134),(1384,'150722','San Mateo',134),(1385,'150723','San Mateo de Otao',134),(1386,'150724','San Pedro de Casta',134),(1387,'150725','San Pedro de Huancayre',134),(1388,'150726','Sangallaya',134),(1389,'150727','Santa Cruz de Cocachacra',134),(1390,'150728','Santa Eulalia',134),(1391,'150729','Santiago de Anchucaya',134),(1392,'150730','Santiago de Tuna',134),(1393,'150731','Santo Domingo de Los Olleros',134),(1394,'150732','Surco',134),(1395,'150801','Huacho',135),(1396,'150802','Ambar',135),(1397,'150803','Caleta de Carquin',135),(1398,'150804','Checras',135),(1399,'150805','Hualmay',135),(1400,'150806','Huaura',135),(1401,'150807','Leoncio Prado',135),(1402,'150808','Paccho',135),(1403,'150809','Santa Leonor',135),(1404,'150810','Santa María',135),(1405,'150811','Sayan',135),(1406,'150812','Vegueta',135),(1407,'150901','Oyon',136),(1408,'150902','Andajes',136),(1409,'150903','Caujul',136),(1410,'150904','Cochamarca',136),(1411,'150905','Navan',136),(1412,'150906','Pachangara',136),(1413,'151001','Yauyos',137),(1414,'151002','Alis',137),(1415,'151003','Allauca',137),(1416,'151004','Ayaviri',137),(1417,'151005','Azángaro',137),(1418,'151006','Cacra',137),(1419,'151007','Carania',137),(1420,'151008','Catahuasi',137),(1421,'151009','Chocos',137),(1422,'151010','Cochas',137),(1423,'151011','Colonia',137),(1424,'151012','Hongos',137),(1425,'151013','Huampara',137),(1426,'151014','Huancaya',137),(1427,'151015','Huangascar',137),(1428,'151016','Huantan',137),(1429,'151017','Huañec',137),(1430,'151018','Laraos',137),(1431,'151019','Lincha',137),(1432,'151020','Madean',137),(1433,'151021','Miraflores',137),(1434,'151022','Omas',137),(1435,'151023','Putinza',137),(1436,'151024','Quinches',137),(1437,'151025','Quinocay',137),(1438,'151026','San Joaquín',137),(1439,'151027','San Pedro de Pilas',137),(1440,'151028','Tanta',137),(1441,'151029','Tauripampa',137),(1442,'151030','Tomas',137),(1443,'151031','Tupe',137),(1444,'151032','Viñac',137),(1445,'151033','Vitis',137),(1446,'160101','Iquitos',138),(1447,'160102','Alto Nanay',138),(1448,'160103','Fernando Lores',138),(1449,'160104','Indiana',138),(1450,'160105','Las Amazonas',138),(1451,'160106','Mazan',138),(1452,'160107','Napo',138),(1453,'160108','Punchana',138),(1454,'160110','Torres Causana',138),(1455,'160112','Belén',138),(1456,'160113','San Juan Bautista',138),(1457,'160201','Yurimaguas',139),(1458,'160202','Balsapuerto',139),(1459,'160205','Jeberos',139),(1460,'160206','Lagunas',139),(1461,'160210','Santa Cruz',139),(1462,'160211','Teniente Cesar López Rojas',139),(1463,'160301','Nauta',140),(1464,'160302','Parinari',140),(1465,'160303','Tigre',140),(1466,'160304','Trompeteros',140),(1467,'160305','Urarinas',140),(1468,'160401','Ramón Castilla',141),(1469,'160402','Pebas',141),(1470,'160403','Yavari',141),(1471,'160404','San Pablo',141),(1472,'160501','Requena',142),(1473,'160502','Alto Tapiche',142),(1474,'160503','Capelo',142),(1475,'160504','Emilio San Martín',142),(1476,'160505','Maquia',142),(1477,'160506','Puinahua',142),(1478,'160507','Saquena',142),(1479,'160508','Soplin',142),(1480,'160509','Tapiche',142),(1481,'160510','Jenaro Herrera',142),(1482,'160511','Yaquerana',142),(1483,'160601','Contamana',143),(1484,'160602','Inahuaya',143),(1485,'160603','Padre Márquez',143),(1486,'160604','Pampa Hermosa',143),(1487,'160605','Sarayacu',143),(1488,'160606','Vargas Guerra',143),(1489,'160701','Barranca',144),(1490,'160702','Cahuapanas',144),(1491,'160703','Manseriche',144),(1492,'160704','Morona',144),(1493,'160705','Pastaza',144),(1494,'160706','Andoas',144),(1495,'160801','Putumayo',145),(1496,'160802','Rosa Panduro',145),(1497,'160803','Teniente Manuel Clavero',145),(1498,'160804','Yaguas',145),(1499,'170101','Tambopata',146),(1500,'170102','Inambari',146),(1501,'170103','Las Piedras',146),(1502,'170104','Laberinto',146),(1503,'170201','Manu',147),(1504,'170202','Fitzcarrald',147),(1505,'170203','Madre de Dios',147),(1506,'170204','Huepetuhe',147),(1507,'170301','Iñapari',148),(1508,'170302','Iberia',148),(1509,'170303','Tahuamanu',148),(1510,'180101','Moquegua',149),(1511,'180102','Carumas',149),(1512,'180103','Cuchumbaya',149),(1513,'180104','Samegua',149),(1514,'180105','San Cristóbal',149),(1515,'180106','Torata',149),(1516,'180201','Omate',150),(1517,'180202','Chojata',150),(1518,'180203','Coalaque',150),(1519,'180204','Ichuña',150),(1520,'180205','La Capilla',150),(1521,'180206','Lloque',150),(1522,'180207','Matalaque',150),(1523,'180208','Puquina',150),(1524,'180209','Quinistaquillas',150),(1525,'180210','Ubinas',150),(1526,'180211','Yunga',150),(1527,'180301','Ilo',151),(1528,'180302','El Algarrobal',151),(1529,'180303','Pacocha',151),(1530,'190101','Chaupimarca',152),(1531,'190102','Huachon',152),(1532,'190103','Huariaca',152),(1533,'190104','Huayllay',152),(1534,'190105','Ninacaca',152),(1535,'190106','Pallanchacra',152),(1536,'190107','Paucartambo',152),(1537,'190108','San Francisco de Asís de Yarusyacan',152),(1538,'190109','Simon Bolívar',152),(1539,'190110','Ticlacayan',152),(1540,'190111','Tinyahuarco',152),(1541,'190112','Vicco',152),(1542,'190113','Yanacancha',152),(1543,'190201','Yanahuanca',153),(1544,'190202','Chacayan',153),(1545,'190203','Goyllarisquizga',153),(1546,'190204','Paucar',153),(1547,'190205','San Pedro de Pillao',153),(1548,'190206','Santa Ana de Tusi',153),(1549,'190207','Tapuc',153),(1550,'190208','Vilcabamba',153),(1551,'190301','Oxapampa',154),(1552,'190302','Chontabamba',154),(1553,'190303','Huancabamba',154),(1554,'190304','Palcazu',154),(1555,'190305','Pozuzo',154),(1556,'190306','Puerto Bermúdez',154),(1557,'190307','Villa Rica',154),(1558,'190308','Constitución',154),(1559,'200101','Piura',155),(1560,'200104','Castilla',155),(1561,'200105','Catacaos',155),(1562,'200107','Cura Mori',155),(1563,'200108','El Tallan',155),(1564,'200109','La Arena',155),(1565,'200110','La Unión',155),(1566,'200111','Las Lomas',155),(1567,'200114','Tambo Grande',155),(1568,'200115','Veintiseis de Octubre',155),(1569,'200201','Ayabaca',156),(1570,'200202','Frias',156),(1571,'200203','Jilili',156),(1572,'200204','Lagunas',156),(1573,'200205','Montero',156),(1574,'200206','Pacaipampa',156),(1575,'200207','Paimas',156),(1576,'200208','Sapillica',156),(1577,'200209','Sicchez',156),(1578,'200210','Suyo',156),(1579,'200301','Huancabamba',157),(1580,'200302','Canchaque',157),(1581,'200303','El Carmen de la Frontera',157),(1582,'200304','Huarmaca',157),(1583,'200305','Lalaquiz',157),(1584,'200306','San Miguel de El Faique',157),(1585,'200307','Sondor',157),(1586,'200308','Sondorillo',157),(1587,'200401','Chulucanas',158),(1588,'200402','Buenos Aires',158),(1589,'200403','Chalaco',158),(1590,'200404','La Matanza',158),(1591,'200405','Morropon',158),(1592,'200406','Salitral',158),(1593,'200407','San Juan de Bigote',158),(1594,'200408','Santa Catalina de Mossa',158),(1595,'200409','Santo Domingo',158),(1596,'200410','Yamango',158),(1597,'200501','Paita',159),(1598,'200502','Amotape',159),(1599,'200503','Arenal',159),(1600,'200504','Colan',159),(1601,'200505','La Huaca',159),(1602,'200506','Tamarindo',159),(1603,'200507','Vichayal',159),(1604,'200601','Sullana',160),(1605,'200602','Bellavista',160),(1606,'200603','Ignacio Escudero',160),(1607,'200604','Lancones',160),(1608,'200605','Marcavelica',160),(1609,'200606','Miguel Checa',160),(1610,'200607','Querecotillo',160),(1611,'200608','Salitral',160),(1612,'200701','Pariñas',161),(1613,'200702','El Alto',161),(1614,'200703','La Brea',161),(1615,'200704','Lobitos',161),(1616,'200705','Los Organos',161),(1617,'200706','Mancora',161),(1618,'200801','Sechura',162),(1619,'200802','Bellavista de la Unión',162),(1620,'200803','Bernal',162),(1621,'200804','Cristo Nos Valga',162),(1622,'200805','Vice',162),(1623,'200806','Rinconada Llicuar',162),(1624,'210101','Puno',163),(1625,'210102','Acora',163),(1626,'210103','Amantani',163),(1627,'210104','Atuncolla',163),(1628,'210105','Capachica',163),(1629,'210106','Chucuito',163),(1630,'210107','Coata',163),(1631,'210108','Huata',163),(1632,'210109','Mañazo',163),(1633,'210110','Paucarcolla',163),(1634,'210111','Pichacani',163),(1635,'210112','Plateria',163),(1636,'210113','San Antonio',163),(1637,'210114','Tiquillaca',163),(1638,'210115','Vilque',163),(1639,'210201','Azángaro',164),(1640,'210202','Achaya',164),(1641,'210203','Arapa',164),(1642,'210204','Asillo',164),(1643,'210205','Caminaca',164),(1644,'210206','Chupa',164),(1645,'210207','José Domingo Choquehuanca',164),(1646,'210208','Muñani',164),(1647,'210209','Potoni',164),(1648,'210210','Saman',164),(1649,'210211','San Anton',164),(1650,'210212','San José',164),(1651,'210213','San Juan de Salinas',164),(1652,'210214','Santiago de Pupuja',164),(1653,'210215','Tirapata',164),(1654,'210301','Macusani',165),(1655,'210302','Ajoyani',165),(1656,'210303','Ayapata',165),(1657,'210304','Coasa',165),(1658,'210305','Corani',165),(1659,'210306','Crucero',165),(1660,'210307','Ituata',165),(1661,'210308','Ollachea',165),(1662,'210309','San Gaban',165),(1663,'210310','Usicayos',165),(1664,'210401','Juli',166),(1665,'210402','Desaguadero',166),(1666,'210403','Huacullani',166),(1667,'210404','Kelluyo',166),(1668,'210405','Pisacoma',166),(1669,'210406','Pomata',166),(1670,'210407','Zepita',166),(1671,'210501','Ilave',167),(1672,'210502','Capazo',167),(1673,'210503','Pilcuyo',167),(1674,'210504','Santa Rosa',167),(1675,'210505','Conduriri',167),(1676,'210601','Huancane',168),(1677,'210602','Cojata',168),(1678,'210603','Huatasani',168),(1679,'210604','Inchupalla',168),(1680,'210605','Pusi',168),(1681,'210606','Rosaspata',168),(1682,'210607','Taraco',168),(1683,'210608','Vilque Chico',168),(1684,'210701','Lampa',169),(1685,'210702','Cabanilla',169),(1686,'210703','Calapuja',169),(1687,'210704','Nicasio',169),(1688,'210705','Ocuviri',169),(1689,'210706','Palca',169),(1690,'210707','Paratia',169),(1691,'210708','Pucara',169),(1692,'210709','Santa Lucia',169),(1693,'210710','Vilavila',169),(1694,'210801','Ayaviri',170),(1695,'210802','Antauta',170),(1696,'210803','Cupi',170),(1697,'210804','Llalli',170),(1698,'210805','Macari',170),(1699,'210806','Nuñoa',170),(1700,'210807','Orurillo',170),(1701,'210808','Santa Rosa',170),(1702,'210809','Umachiri',170),(1703,'210901','Moho',171),(1704,'210902','Conima',171),(1705,'210903','Huayrapata',171),(1706,'210904','Tilali',171),(1707,'211001','Putina',172),(1708,'211002','Ananea',172),(1709,'211003','Pedro Vilca Apaza',172),(1710,'211004','Quilcapuncu',172),(1711,'211005','Sina',172),(1712,'211101','Juliaca',173),(1713,'211102','Cabana',173),(1714,'211103','Cabanillas',173),(1715,'211104','Caracoto',173),(1716,'211201','Sandia',174),(1717,'211202','Cuyocuyo',174),(1718,'211203','Limbani',174),(1719,'211204','Patambuco',174),(1720,'211205','Phara',174),(1721,'211206','Quiaca',174),(1722,'211207','San Juan del Oro',174),(1723,'211208','Yanahuaya',174),(1724,'211209','Alto Inambari',174),(1725,'211210','San Pedro de Putina Punco',174),(1726,'211301','Yunguyo',175),(1727,'211302','Anapia',175),(1728,'211303','Copani',175),(1729,'211304','Cuturapi',175),(1730,'211305','Ollaraya',175),(1731,'211306','Tinicachi',175),(1732,'211307','Unicachi',175),(1733,'220101','Moyobamba',176),(1734,'220102','Calzada',176),(1735,'220103','Habana',176),(1736,'220104','Jepelacio',176),(1737,'220105','Soritor',176),(1738,'220106','Yantalo',176),(1739,'220201','Bellavista',177),(1740,'220202','Alto Biavo',177),(1741,'220203','Bajo Biavo',177),(1742,'220204','Huallaga',177),(1743,'220205','San Pablo',177),(1744,'220206','San Rafael',177),(1745,'220301','San José de Sisa',178),(1746,'220302','Agua Blanca',178),(1747,'220303','San Martín',178),(1748,'220304','Santa Rosa',178),(1749,'220305','Shatoja',178),(1750,'220401','Saposoa',179),(1751,'220402','Alto Saposoa',179),(1752,'220403','El Eslabón',179),(1753,'220404','Piscoyacu',179),(1754,'220405','Sacanche',179),(1755,'220406','Tingo de Saposoa',179),(1756,'220501','Lamas',180),(1757,'220502','Alonso de Alvarado',180),(1758,'220503','Barranquita',180),(1759,'220504','Caynarachi',180),(1760,'220505','Cuñumbuqui',180),(1761,'220506','Pinto Recodo',180),(1762,'220507','Rumisapa',180),(1763,'220508','San Roque de Cumbaza',180),(1764,'220509','Shanao',180),(1765,'220510','Tabalosos',180),(1766,'220511','Zapatero',180),(1767,'220601','Juanjuí',181),(1768,'220602','Campanilla',181),(1769,'220603','Huicungo',181),(1770,'220604','Pachiza',181),(1771,'220605','Pajarillo',181),(1772,'220701','Picota',182),(1773,'220702','Buenos Aires',182),(1774,'220703','Caspisapa',182),(1775,'220704','Pilluana',182),(1776,'220705','Pucacaca',182),(1777,'220706','San Cristóbal',182),(1778,'220707','San Hilarión',182),(1779,'220708','Shamboyacu',182),(1780,'220709','Tingo de Ponasa',182),(1781,'220710','Tres Unidos',182),(1782,'220801','Rioja',183),(1783,'220802','Awajun',183),(1784,'220803','Elías Soplin Vargas',183),(1785,'220804','Nueva Cajamarca',183),(1786,'220805','Pardo Miguel',183),(1787,'220806','Posic',183),(1788,'220807','San Fernando',183),(1789,'220808','Yorongos',183),(1790,'220809','Yuracyacu',183),(1791,'220901','Tarapoto',184),(1792,'220902','Alberto Leveau',184),(1793,'220903','Cacatachi',184),(1794,'220904','Chazuta',184),(1795,'220905','Chipurana',184),(1796,'220906','El Porvenir',184),(1797,'220907','Huimbayoc',184),(1798,'220908','Juan Guerra',184),(1799,'220909','La Banda de Shilcayo',184),(1800,'220910','Morales',184),(1801,'220911','Papaplaya',184),(1802,'220912','San Antonio',184),(1803,'220913','Sauce',184),(1804,'220914','Shapaja',184),(1805,'221001','Tocache',185),(1806,'221002','Nuevo Progreso',185),(1807,'221003','Polvora',185),(1808,'221004','Shunte',185),(1809,'221005','Uchiza',185),(1810,'230101','Tacna',186),(1811,'230102','Alto de la Alianza',186),(1812,'230103','Calana',186),(1813,'230104','Ciudad Nueva',186),(1814,'230105','Inclan',186),(1815,'230106','Pachia',186),(1816,'230107','Palca',186),(1817,'230108','Pocollay',186),(1818,'230109','Sama',186),(1819,'230110','Coronel Gregorio Albarracín Lanchipa',186),(1820,'230111','La Yarada los Palos',186),(1821,'230201','Candarave',187),(1822,'230202','Cairani',187),(1823,'230203','Camilaca',187),(1824,'230204','Curibaya',187),(1825,'230205','Huanuara',187),(1826,'230206','Quilahuani',187),(1827,'230301','Locumba',188),(1828,'230302','Ilabaya',188),(1829,'230303','Ite',188),(1830,'230401','Tarata',189),(1831,'230402','Héroes Albarracín',189),(1832,'230403','Estique',189),(1833,'230404','Estique-Pampa',189),(1834,'230405','Sitajara',189),(1835,'230406','Susapaya',189),(1836,'230407','Tarucachi',189),(1837,'230408','Ticaco',189),(1838,'240101','Tumbes',190),(1839,'240102','Corrales',190),(1840,'240103','La Cruz',190),(1841,'240104','Pampas de Hospital',190),(1842,'240105','San Jacinto',190),(1843,'240106','San Juan de la Virgen',190),(1844,'240201','Zorritos',191),(1845,'240202','Casitas',191),(1846,'240203','Canoas de Punta Sal',191),(1847,'240301','Zarumilla',192),(1848,'240302','Aguas Verdes',192),(1849,'240303','Matapalo',192),(1850,'240304','Papayal',192),(1851,'250101','Calleria',193),(1852,'250102','Campoverde',193),(1853,'250103','Iparia',193),(1854,'250104','Masisea',193),(1855,'250105','Yarinacocha',193),(1856,'250106','Nueva Requena',193),(1857,'250107','Manantay',193),(1858,'250201','Raymondi',194),(1859,'250202','Sepahua',194),(1860,'250203','Tahuania',194),(1861,'250204','Yurua',194),(1862,'250301','Padre Abad',195),(1863,'250302','Irazola',195),(1864,'250303','Curimana',195),(1865,'250304','Neshuya',195),(1866,'250305','Alexander Von Humboldt',195),(1867,'250401','Purus',196);
/*!40000 ALTER TABLE `distrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,1,'Dashboard','','_self','voyager-boat',NULL,NULL,1,'2019-04-23 21:06:52','2019-04-23 21:06:52','voyager.dashboard',NULL),(2,1,'Media','','_self','voyager-images',NULL,NULL,5,'2019-04-23 21:06:52','2019-04-23 21:22:46','voyager.media.index',NULL),(3,1,'Users','','_self','voyager-person',NULL,NULL,4,'2019-04-23 21:06:52','2019-04-23 21:22:45','voyager.users.index',NULL),(4,1,'Roles','','_self','voyager-lock',NULL,NULL,3,'2019-04-23 21:06:52','2019-04-23 21:22:45','voyager.roles.index',NULL),(5,1,'Tools','','_self','voyager-tools',NULL,NULL,6,'2019-04-23 21:06:52','2019-04-23 21:22:46',NULL,NULL),(6,1,'Menu Builder','','_self','voyager-list',NULL,5,1,'2019-04-23 21:06:52','2019-04-23 21:21:55','voyager.menus.index',NULL),(7,1,'Database','','_self','voyager-data',NULL,5,2,'2019-04-23 21:06:52','2019-04-23 21:21:55','voyager.database.index',NULL),(8,1,'Compass','','_self','voyager-compass',NULL,5,3,'2019-04-23 21:06:52','2019-04-23 21:21:55','voyager.compass.index',NULL),(9,1,'BREAD','','_self','voyager-bread',NULL,5,4,'2019-04-23 21:06:52','2019-04-23 21:21:55','voyager.bread.index',NULL),(10,1,'Settings','','_self','voyager-settings',NULL,NULL,7,'2019-04-23 21:06:52','2019-04-23 21:22:46','voyager.settings.index',NULL),(11,1,'Hooks','','_self','voyager-hook',NULL,5,5,'2019-04-23 21:06:55','2019-04-23 21:21:55','voyager.hooks',NULL),(12,1,'Regions','','_self',NULL,NULL,14,1,'2019-04-23 21:17:24','2019-04-23 21:22:05','voyager.region.index',NULL),(13,1,'Provincias','','_self',NULL,NULL,14,2,'2019-04-23 21:20:57','2019-04-23 21:22:09','voyager.provincias.index',NULL),(14,1,'Ubigeo','','_self','voyager-list','#000000',NULL,2,'2019-04-23 21:21:49','2019-04-23 21:21:58',NULL,''),(15,1,'Distritos','','_self',NULL,NULL,14,3,'2019-04-23 21:22:27','2019-04-23 21:22:45','voyager.distrito.index',NULL);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'admin','2019-04-23 21:06:52','2019-04-23 21:06:52');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_01_000000_add_voyager_user_fields',1),(4,'2016_01_01_000000_create_data_types_table',1),(5,'2016_05_19_173453_create_menu_table',1),(6,'2016_10_21_190000_create_roles_table',1),(7,'2016_10_21_190000_create_settings_table',1),(8,'2016_11_30_135954_create_permission_table',1),(9,'2016_11_30_141208_create_permission_role_table',1),(10,'2016_12_26_201236_data_types__add__server_side',1),(11,'2017_01_13_000000_add_route_to_menu_items_table',1),(12,'2017_01_14_005015_create_translations_table',1),(13,'2017_01_15_000000_make_table_name_nullable_in_permissions_table',1),(14,'2017_03_06_000000_add_controller_to_data_types_table',1),(15,'2017_04_21_000000_add_order_to_data_rows_table',1),(16,'2017_07_05_210000_add_policyname_to_data_types_table',1),(17,'2017_08_05_000000_add_group_to_settings_table',1),(18,'2017_11_26_013050_add_user_role_relationship',1),(19,'2017_11_26_015000_create_user_roles_table',1),(20,'2018_03_11_000000_add_user_settings',1),(21,'2018_03_14_000000_add_details_to_data_types_table',1),(22,'2018_03_16_000000_make_settings_value_nullable',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_permission_id_index` (`permission_id`),
  KEY `permission_role_role_id_index` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'browse_admin',NULL,'2019-04-23 21:06:52','2019-04-23 21:06:52'),(2,'browse_bread',NULL,'2019-04-23 21:06:52','2019-04-23 21:06:52'),(3,'browse_database',NULL,'2019-04-23 21:06:53','2019-04-23 21:06:53'),(4,'browse_media',NULL,'2019-04-23 21:06:53','2019-04-23 21:06:53'),(5,'browse_compass',NULL,'2019-04-23 21:06:53','2019-04-23 21:06:53'),(6,'browse_menus','menus','2019-04-23 21:06:53','2019-04-23 21:06:53'),(7,'read_menus','menus','2019-04-23 21:06:53','2019-04-23 21:06:53'),(8,'edit_menus','menus','2019-04-23 21:06:53','2019-04-23 21:06:53'),(9,'add_menus','menus','2019-04-23 21:06:53','2019-04-23 21:06:53'),(10,'delete_menus','menus','2019-04-23 21:06:53','2019-04-23 21:06:53'),(11,'browse_roles','roles','2019-04-23 21:06:53','2019-04-23 21:06:53'),(12,'read_roles','roles','2019-04-23 21:06:53','2019-04-23 21:06:53'),(13,'edit_roles','roles','2019-04-23 21:06:53','2019-04-23 21:06:53'),(14,'add_roles','roles','2019-04-23 21:06:53','2019-04-23 21:06:53'),(15,'delete_roles','roles','2019-04-23 21:06:53','2019-04-23 21:06:53'),(16,'browse_users','users','2019-04-23 21:06:53','2019-04-23 21:06:53'),(17,'read_users','users','2019-04-23 21:06:53','2019-04-23 21:06:53'),(18,'edit_users','users','2019-04-23 21:06:53','2019-04-23 21:06:53'),(19,'add_users','users','2019-04-23 21:06:53','2019-04-23 21:06:53'),(20,'delete_users','users','2019-04-23 21:06:53','2019-04-23 21:06:53'),(21,'browse_settings','settings','2019-04-23 21:06:53','2019-04-23 21:06:53'),(22,'read_settings','settings','2019-04-23 21:06:53','2019-04-23 21:06:53'),(23,'edit_settings','settings','2019-04-23 21:06:53','2019-04-23 21:06:53'),(24,'add_settings','settings','2019-04-23 21:06:53','2019-04-23 21:06:53'),(25,'delete_settings','settings','2019-04-23 21:06:53','2019-04-23 21:06:53'),(26,'browse_hooks',NULL,'2019-04-23 21:06:55','2019-04-23 21:06:55'),(27,'browse_region','region','2019-04-23 21:17:23','2019-04-23 21:17:23'),(28,'read_region','region','2019-04-23 21:17:23','2019-04-23 21:17:23'),(29,'edit_region','region','2019-04-23 21:17:23','2019-04-23 21:17:23'),(30,'add_region','region','2019-04-23 21:17:23','2019-04-23 21:17:23'),(31,'delete_region','region','2019-04-23 21:17:23','2019-04-23 21:17:23'),(32,'browse_provincias','provincias','2019-04-23 21:20:57','2019-04-23 21:20:57'),(33,'read_provincias','provincias','2019-04-23 21:20:57','2019-04-23 21:20:57'),(34,'edit_provincias','provincias','2019-04-23 21:20:57','2019-04-23 21:20:57'),(35,'add_provincias','provincias','2019-04-23 21:20:57','2019-04-23 21:20:57'),(36,'delete_provincias','provincias','2019-04-23 21:20:57','2019-04-23 21:20:57'),(37,'browse_distrito','distrito','2019-04-23 21:22:27','2019-04-23 21:22:27'),(38,'read_distrito','distrito','2019-04-23 21:22:27','2019-04-23 21:22:27'),(39,'edit_distrito','distrito','2019-04-23 21:22:27','2019-04-23 21:22:27'),(40,'add_distrito','distrito','2019-04-23 21:22:27','2019-04-23 21:22:27'),(41,'delete_distrito','distrito','2019-04-23 21:22:27','2019-04-23 21:22:27');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provincias`
--

DROP TABLE IF EXISTS `provincias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idregion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincias`
--

LOCK TABLES `provincias` WRITE;
/*!40000 ALTER TABLE `provincias` DISABLE KEYS */;
INSERT INTO `provincias` VALUES (1,'0101','Chachapoyas',1),(2,'0102','Bagua',1),(3,'0103','Bongará',1),(4,'0104','Condorcanqui',1),(5,'0105','Luya',1),(6,'0106','Rodríguez de Mendoza',1),(7,'0107','Utcubamba',1),(8,'0201','Huaraz',2),(9,'0202','Aija',2),(10,'0203','Antonio Raymondi',2),(11,'0204','Asunción',2),(12,'0205','Bolognesi',2),(13,'0206','Carhuaz',2),(14,'0207','Carlos Fermín Fitzcarrald',2),(15,'0208','Casma',2),(16,'0209','Corongo',2),(17,'0210','Huari',2),(18,'0211','Huarmey',2),(19,'0212','Huaylas',2),(20,'0213','Mariscal Luzuriaga',2),(21,'0214','Ocros',2),(22,'0215','Pallasca',2),(23,'0216','Pomabamba',2),(24,'0217','Recuay',2),(25,'0218','Santa',2),(26,'0219','Sihuas',2),(27,'0220','Yungay',2),(28,'0301','Abancay',3),(29,'0302','Andahuaylas',3),(30,'0303','Antabamba',3),(31,'0304','Aymaraes',3),(32,'0305','Cotabambas',3),(33,'0306','Chincheros',3),(34,'0307','Grau',3),(35,'0401','Arequipa',4),(36,'0402','Camaná',4),(37,'0403','Caravelí',4),(38,'0404','Castilla',4),(39,'0405','Caylloma',4),(40,'0406','Condesuyos',4),(41,'0407','Islay',4),(42,'0408','La Uniòn',4),(43,'0501','Huamanga',5),(44,'0502','Cangallo',5),(45,'0503','Huanca Sancos',5),(46,'0504','Huanta',5),(47,'0505','La Mar',5),(48,'0506','Lucanas',5),(49,'0507','Parinacochas',5),(50,'0508','Pàucar del Sara Sara',5),(51,'0509','Sucre',5),(52,'0510','Víctor Fajardo',5),(53,'0511','Vilcas Huamán',5),(54,'0601','Cajamarca',6),(55,'0602','Cajabamba',6),(56,'0603','Celendín',6),(57,'0604','Chota',6),(58,'0605','Contumazá',6),(59,'0606','Cutervo',6),(60,'0607','Hualgayoc',6),(61,'0608','Jaén',6),(62,'0609','San Ignacio',6),(63,'0610','San Marcos',6),(64,'0611','San Miguel',6),(65,'0612','San Pablo',6),(66,'0613','Santa Cruz',6),(67,'0701','Prov. Const. del Callao',7),(68,'0801','Cusco',8),(69,'0802','Acomayo',8),(70,'0803','Anta',8),(71,'0804','Calca',8),(72,'0805','Canas',8),(73,'0806','Canchis',8),(74,'0807','Chumbivilcas',8),(75,'0808','Espinar',8),(76,'0809','La Convención',8),(77,'0810','Paruro',8),(78,'0811','Paucartambo',8),(79,'0812','Quispicanchi',8),(80,'0813','Urubamba',8),(81,'0901','Huancavelica',9),(82,'0902','Acobamba',9),(83,'0903','Angaraes',9),(84,'0904','Castrovirreyna',9),(85,'0905','Churcampa',9),(86,'0906','Huaytará',9),(87,'0907','Tayacaja',9),(88,'1001','Huánuco',10),(89,'1002','Ambo',10),(90,'1003','Dos de Mayo',10),(91,'1004','Huacaybamba',10),(92,'1005','Huamalíes',10),(93,'1006','Leoncio Prado',10),(94,'1007','Marañón',10),(95,'1008','Pachitea',10),(96,'1009','Puerto Inca',10),(97,'1010','Lauricocha ',10),(98,'1011','Yarowilca ',10),(99,'1101','Ica ',11),(100,'1102','Chincha ',11),(101,'1103','Nasca ',11),(102,'1104','Palpa ',11),(103,'1105','Pisco ',11),(104,'1201','Huancayo ',12),(105,'1202','Concepción ',12),(106,'1203','Chanchamayo ',12),(107,'1204','Jauja ',12),(108,'1205','Junín ',12),(109,'1206','Satipo ',12),(110,'1207','Tarma ',12),(111,'1208','Yauli ',12),(112,'1209','Chupaca ',12),(113,'1301','Trujillo ',13),(114,'1302','Ascope ',13),(115,'1303','Bolívar ',13),(116,'1304','Chepén ',13),(117,'1305','Julcán ',13),(118,'1306','Otuzco ',13),(119,'1307','Pacasmayo ',13),(120,'1308','Pataz ',13),(121,'1309','Sánchez Carrión ',13),(122,'1310','Santiago de Chuco ',13),(123,'1311','Gran Chimú ',13),(124,'1312','Virú ',13),(125,'1401','Chiclayo ',14),(126,'1402','Ferreñafe ',14),(127,'1403','Lambayeque ',14),(128,'1501','Lima ',15),(129,'1502','Barranca ',15),(130,'1503','Cajatambo ',15),(131,'1504','Canta ',15),(132,'1505','Cañete ',15),(133,'1506','Huaral ',15),(134,'1507','Huarochirí ',15),(135,'1508','Huaura ',15),(136,'1509','Oyón ',15),(137,'1510','Yauyos ',15),(138,'1601','Maynas ',16),(139,'1602','Alto Amazonas ',16),(140,'1603','Loreto ',16),(141,'1604','Mariscal Ramón Castilla ',16),(142,'1605','Requena ',16),(143,'1606','Ucayali ',16),(144,'1607','Datem del Marañón ',16),(145,'1608','Putumayo',16),(146,'1701','Tambopata ',17),(147,'1702','Manu ',17),(148,'1703','Tahuamanu ',17),(149,'1801','Mariscal Nieto ',18),(150,'1802','General Sánchez Cerro ',18),(151,'1803','Ilo ',18),(152,'1901','Pasco ',19),(153,'1902','Daniel Alcides Carrión ',19),(154,'1903','Oxapampa ',19),(155,'2001','Piura ',20),(156,'2002','Ayabaca ',20),(157,'2003','Huancabamba ',20),(158,'2004','Morropón ',20),(159,'2005','Paita ',20),(160,'2006','Sullana ',20),(161,'2007','Talara ',20),(162,'2008','Sechura ',20),(163,'2101','Puno ',21),(164,'2102','Azángaro ',21),(165,'2103','Carabaya ',21),(166,'2104','Chucuito ',21),(167,'2105','El Collao ',21),(168,'2106','Huancané ',21),(169,'2107','Lampa ',21),(170,'2108','Melgar ',21),(171,'2109','Moho ',21),(172,'2110','San Antonio de Putina ',21),(173,'2111','San Román ',21),(174,'2112','Sandia ',21),(175,'2113','Yunguyo ',21),(176,'2201','Moyobamba ',22),(177,'2202','Bellavista ',22),(178,'2203','El Dorado ',22),(179,'2204','Huallaga ',22),(180,'2205','Lamas ',22),(181,'2206','Mariscal Cáceres ',22),(182,'2207','Picota ',22),(183,'2208','Rioja ',22),(184,'2209','San Martín ',22),(185,'2210','Tocache ',22),(186,'2301','Tacna ',23),(187,'2302','Candarave ',23),(188,'2303','Jorge Basadre ',23),(189,'2304','Tarata ',23),(190,'2401','Tumbes ',24),(191,'2402','Contralmirante Villar ',24),(192,'2403','Zarumilla ',24),(193,'2501','Coronel Portillo ',25),(194,'2502','Atalaya ',25),(195,'2503','Padre Abad ',25),(196,'2504','Purús',25);
/*!40000 ALTER TABLE `provincias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'01','Amazonas'),(2,'02','Áncash'),(3,'03','Apurímac'),(4,'04','Arequipa'),(5,'05','Ayacucho'),(6,'06','Cajamarca'),(7,'07','Callao'),(8,'08','Cusco'),(9,'09','Huancavelica'),(10,'10','Huánuco'),(11,'11','Ica'),(12,'12','Junín'),(13,'13','La Libertad'),(14,'14','Lambayeque'),(15,'15','Lima'),(16,'16','Loreto'),(17,'17','Madre de Dios'),(18,'18','Moquegua'),(19,'19','Pasco'),(20,'20','Piura'),(21,'21','Puno'),(22,'22','San Martín'),(23,'23','Tacna'),(24,'24','Tumbes'),(25,'25','Ucayali');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrator','2019-04-23 21:06:52','2019-04-23 21:06:52'),(2,'user','Normal User','2019-04-23 21:06:52','2019-04-23 21:06:52');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'site.title','Site Title','Site Title','','text',1,'Site'),(2,'site.description','Site Description','Site Description','','text',2,'Site'),(3,'site.logo','Site Logo','','','image',3,'Site'),(4,'site.google_analytics_tracking_id','Google Analytics Tracking ID','','','text',4,'Site'),(5,'admin.bg_image','Admin Background Image','','','image',5,'Admin'),(6,'admin.title','Admin Title','Voyager','','text',1,'Admin'),(7,'admin.description','Admin Description','Welcome to Voyager. The Missing Admin for Laravel','','text',2,'Admin'),(8,'admin.loader','Admin Loader','','','image',3,'Admin'),(9,'admin.icon_image','Admin Icon Image','','','image',4,'Admin'),(10,'admin.google_analytics_client_id','Google Analytics Client ID (used for admin dashboard)','','','text',1,'Admin');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_roles_user_id_index` (`user_id`),
  KEY `user_roles_role_id_index` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Luis Mayta','luis.mayta@gmail.com','users/default.png',NULL,'$2y$10$P/EpTe8CtqtwFMZCtuEG/uZHIZDjviWgO7GFSfmScTIK1mx3o82qW',NULL,NULL,'2019-04-23 21:07:28','2019-04-23 21:07:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-23 11:44:47
